from setuptools import setup

setup(name='EasyRegression',
      version='0.1',
      url='https://github.com/peerlator/easyregression',
      description="A Plug n' Play library for poliynomial regression",
      author='Peerlator',
      packages=['EasyRegression'],
      zip_safe=False)
